package hw5;
import java.io.Serializable;

public class ChatMessage implements Serializable {
	public static final long serialVersionUID = 1;
	private String username="";
	private String game="";
	private int shouldHit=0;
	private String message="";
	private boolean error=false;;
	private int gameSize=0;
	private boolean bets;
	private int chips;
	private boolean checkGame=false;
	private boolean gameExists=false;
	private int bet;
	private boolean hits;
	
	//constructor to initialize username and game
	public ChatMessage(String username, String message) {
		this.setUsername(username);
		this.setGame(message);
	}
	//constructor to initialize a message
	public ChatMessage(String msg)
	{
		this.setMessage(msg);
	}
	//no parameter constructor
	public ChatMessage()
	{
		
	}
	
	//getter method
	public String getUsername() {
		return username;
	}
	//setter method
	public void setUsername(String username) {
		this.username = username;
	}
	//getter method
	public String getGame() {
		return game;
	}
	//setter method
	public void setGame(String game) {
		this.game = game;
	}
	//getter method
	public boolean isError() {
		return error;
	}
	//setter method
	public void setError(boolean error) {
		this.error = error;
	}
	//getter method
	public String getMessage() {
		return message;
	}
	//setter method
	public void setMessage(String message) {
		this.message = message;
	}
	//getter method
	public int getGameSize() {
		return gameSize;
	}
	//setter method
	public void setGameSize(int gameSize) {
		this.gameSize = gameSize;
	}
	//getter method
	public boolean isBets() {
		return bets;
	}
	//setter method
	public void setBets(boolean bets) {
		this.bets = bets;
	}
	//getter method
	public boolean isHits() {
		return hits;
	}
	//setter method
	public void setHits(boolean hits) {
		this.hits = hits;
	}
	//getter method
	public int getChips() {
		return chips;
	}
	//setter method
	public void setChips(int chips) {
		this.chips = chips;
	}
	//getter method
	public int getBet() {
		return bet;
	}
	//setter method
	public void setBet(int bet) {
		this.bet = bet;
	}
	//getter method
	public int getShouldHit() {
		return shouldHit;
	}
	//setter method
	public void setShouldHit(int shouldHit) {
		this.shouldHit = shouldHit;
	}
	//getter method
	public boolean isCheckGame() {
		return checkGame;
	}
	//setter method
	public void setCheckGame(boolean checkGame) {
		this.checkGame = checkGame;
	}
	//getter method
	public boolean isGameExists() {
		return gameExists;
	}
	//setter method
	public void setGameExists(boolean gameExists) {
		this.gameExists = gameExists;
	}

}