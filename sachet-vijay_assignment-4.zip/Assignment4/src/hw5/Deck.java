package hw5;
import java.util.Random;
public class Deck {
	String[] deck = new String[52];
	int[] deckfill = new int[52];
	
	//constructor, initializes the deck array with their card values
	public Deck()
	{
		for(int i=1;i<=52;i++)
		{
			deckfill[i-1]=0;
			String card="";
			if(i<=4)
			{
				card+="ACE of ";
			}
			else if(i<=8)
			{
				card+="TWO of ";				
			}
			else if(i<=12)
			{
				card+="THREE of ";				
			}
			else if(i<=16)
			{
				card+="FOUR of ";				
			}
			else if(i<=20)
			{
				card+="FIVE of ";				
			}
			else if(i<=24)
			{
				card+="SIX of ";				
			}
			else if(i<=28)
			{
				card+="SEVEN of ";				
			}
			else if(i<=32)
			{
				card+="EIGHT of ";				
			}
			else if(i<=36)
			{
				card+="NINE of ";				
			}
			else if(i<=40)
			{
				card+="TEN of ";				
			}
			else if(i<=44)
			{
				card+="JACK of ";				
			}
			else if(i<=48)
			{
				card+="QUEEN of ";				
			}
			else if(i<=52)
			{
				card+="KING of ";				
			}
			if(i%4==0)
			{
				card+="SPADES";
			}
			else if(i%4==1)
			{
				card+="DIAMONDS";				
			}
			else if(i%4==2)
			{
				card+="HEARTS";				
			}
			else if(i%4==3)
			{
				card+="CLUBS";				
			}
			deck[i-1]=card;
		}
	}
	
	//returns the string representation of a card, given the index value
	public String getString(int index)
	{
		return deck[index];
	}
	
	//resets the deck, such that any card could be chosen again
	public void flush()
	{
		for(int i=1;i<=52;i++)
		{
			deckfill[i-1]=0;
		}
	}
	
	//among indexes for which deckfill is not 0, randomly chooses a index, to represent shuffling.
	public int random()
	{
		Random rand = new Random();
		while(true)
		{
			int  n = rand.nextInt(52);
			if(deckfill[n]==0)
			{
				deckfill[n]=1;
				return n;
			}
		}
	}
	
	//given an index, returns the corresponding card's value according to jackblack
	public int getValue(int i)
	{
		if(i<4)
		{
			return 11;
		}
		else if(i<8)
		{
			return 2;			
		}
		else if(i<12)
		{
			return 3;		
		}
		else if(i<16)
		{
			return 4;			
		}
		else if(i<20)
		{
			return 5;			
		}
		else if(i<24)
		{
			return 6;			
		}
		else if(i<28)
		{
			return 7;			
		}
		else if(i<32)
		{
			return 8;				
		}
		else if(i<36)
		{
			return 9;				
		}
		else
		{
			return 10;					
		}
	}
}
