          package hw5.client;
import java.util.*;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import hw5.ChatMessage;
public class Player extends Thread {
	private String username;
	private String gameName;
	private int gameSize=0;
	private int chips;
	private int bet=-1;
	private int status;
	private int respNotReceived=0;
	private ArrayList<Integer> cards = new ArrayList<Integer>();
	private ObjectInputStream ois;
	private ObjectOutputStream oos;	
	private Socket s;
	
	// constructor, starts thread
	public Player()
	{
		this.start();
	}
	
	//prompts user questions to start game
	public void startGame()
	{
		Scanner sc=new Scanner(System.in); 
		System.out.println("Please choose from the options below \n1) Start Game\n2) Join Game");
		
		int result=0;
		result=sc.nextInt();
		if(result==1)
		{
			//making sure gamesize is valid
			boolean sizeInValid=true;
			while(sizeInValid)
			{
				System.out.println("Please choose the number of players in the game");
				gameSize = sc.nextInt();
				if(gameSize>=1 && gameSize <=3)
				{
					sizeInValid=false;
				}
				else
				{
					System.out.println("Please choose a value between 1 and 3 inclusive");
				}
			}
			boolean gameInvalid=true;
			
			//making sure gamename is valid
			while(gameInvalid)
			{
				System.out.println("Please choose a name for your game");
				gameName = sc.next();
				ChatMessage cm = new ChatMessage();
				cm.setGame(gameName);
				cm.setCheckGame(true);
				try {
					oos.writeObject(cm);
					oos.flush();
				} catch (IOException e) {
				}
				
				while(respNotReceived==0)
				{
					
					ChatMessage cmObject=null;
					try {
						cmObject = (ChatMessage)ois.readObject();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(cmObject.isCheckGame())
					{
						if(cmObject.isGameExists())
						{
							respNotReceived=2;
						}
						else { 
							respNotReceived=1;
							}	
					}
					System.err.print("");
				}
				if(respNotReceived==1)
				{
					gameInvalid=false;
				}
				else
				{
					respNotReceived=0;
					System.out.println("Invalid Choice. The gamename has already been chosen by another user");
				}
			}
			//making sure username is valid
			boolean usernameInvalid=true;
			while(usernameInvalid)
			{
				System.out.println("Please choose a username");
				username = sc.next();
				if(username.equals("")==false)
				{
					usernameInvalid=false;
				}
				else
				{
					System.out.println("Enter valid username");
				}
			}
		}
		else if(result==2)
		{
			//making sure gamename is valid
			boolean gameInvalid=true;
			while(gameInvalid)
			{
				System.out.println("Please enter the name of the game you wish to join");
				gameName = sc.next();
				ChatMessage cm = new ChatMessage();
				cm.setGame(gameName);
				cm.setCheckGame(true);
				try {
					oos.writeObject(cm);
					oos.flush();
				} catch (IOException e) {
				}
				
				while(respNotReceived==0)
				{
					ChatMessage cmObject=null;
					try {
						cmObject = (ChatMessage)ois.readObject();
					} catch (ClassNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
					if(cmObject.isCheckGame())
					{
						if(cmObject.isGameExists())
						{
							respNotReceived=2;}
						else { respNotReceived=1;}
						
					}
					System.err.print("");
				}
				if(respNotReceived==2)
				{
					gameInvalid=false;
				}
				else
				{
					respNotReceived=0;
					System.out.println("Invalid Choice. There are no ongoing games with this name");
				}
			}
			//making sure username is valid
			boolean usernameInvalid=true;
			while(usernameInvalid)
			{
				System.out.println("Please choose a username");
				username = sc.next();
				if(username.equals("")==false)
				{
					usernameInvalid=false;
				}
				else
				{
					System.out.println("Enter valid username");
				}
			}		
		}
	}
	
	//main method
	public static void main(String [] args)
	{
		Player p=new Player();
	}
	
	//run thread inherited from Thread class
	public void run() {
		Scanner sc=new Scanner(System.in); 
		 Socket socket;
		 ObjectOutputStream oos=null;
		 ObjectInputStream ois = null;
			try {
				socket = new Socket("localhost", 6789);
				oos = new ObjectOutputStream(socket.getOutputStream());
				ois = new ObjectInputStream(socket.getInputStream());
				
			} 
			catch (EOFException exc) {
		        return;
		    }catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		while(true)
		{
				try {
					ChatMessage cm=null;
					while(true)
					{
					cm = (ChatMessage)ois.readObject();
					if(cm!=null)break;
					}
					String s = cm.getMessage();
					if(s.equals("1"))
					{
						System.out.print("Player 1 Bet - $");
						String res = sc.next();

						oos.writeObject(res);

					}
					else if(s.substring(0, 1).equals("3"))
					{
						System.out.println("Do you agree with bet: "+s.substring(1) );
						String res = sc.next();
						oos.writeObject(res);
					}
					else if(s.equals("2"))
					{
						System.out.println("Thank you for playing war.");
						return;
					}
					else if(s.substring(0, 1).equals("4"))
					{
						System.out.println("Player 1 Card - "+s.substring(1,2));
						System.out.println("Player 2 Card - "+s.substring(2,3));
						if(s.substring(3, 4).equals("t"))
						{
							System.out.println("There is war, enter any character to continue");
							String ok = sc.next();
							oos.writeObject(ok);
						}
						else if(s.substring(3, 4).equals("w"))
						{
							System.out.println("Player 1 wins $"+s.substring(4));
							System.out.println("Player 2 loses $"+s.substring(4));
						}
						else if(s.substring(3, 4).equals("l"))
						{
							System.out.println("Player 1 loses $"+s.substring(4));
							System.out.println("Player 2 wins $"+s.substring(4));	
						}
					}
					else if(s.substring(0, 1).equals("5"))
					{
						
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				catch (EOFException exc) {
			        break;
			    } catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


			
		}
	}
	
	
}