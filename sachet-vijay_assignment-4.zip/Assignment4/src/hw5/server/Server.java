package hw5.server;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

import hw5.ChatMessage;
public class Server extends Thread{
	private HashMap<String, ArrayList<PlayerThread>> hmap = new HashMap<String, ArrayList<PlayerThread>>();
	private HashMap<String, Integer> gameSize = new HashMap<String,Integer>();
	private boolean startG = false;
	ArrayList<Socket> threads= new ArrayList<Socket>();
	private ObjectInputStream ois1;
	private ObjectOutputStream oos1;	
	private ObjectInputStream ois2;
	private ObjectOutputStream oos2;	
	private ServerSocket serverSocket;
	String mess="";
	//checks to see if a game, being the gamename, exists in hmap
	public boolean gameExists(String game)
	{
		System.out.println("is result: "+hmap.containsKey(game));
		return hmap.containsKey(game);
	}
	//constructor, starts the thread
	public Server()
	{
		this.start();
	}
	
	//main method
	public static void main(String args[])
	{
		Server server = new Server();
	}
	
	//s is gamename
	//removes corresponding game from hmap
	public void removeGame(String s)
	{
		hmap.remove(s);
	}
	
	//starts game if correct number of players, equal to game size
	//s represents gamename
	//returns 1 if start, 0 if too little, 2 if too high, 3 if just one
	public int startGame(String s)
	{
		if(hmap.get(s).size() == gameSize.get(s))
		{
			Dealer deal= new Dealer(hmap.get(s), this, s);
			ChatMessage cm = new ChatMessage();
			cm.setGame(s);
			cm.setMessage("Let the game commence. Good luck to all players!");
			broadcastHead(cm);
			return 1;
		}
		else if(hmap.get(s).size() > gameSize.get(s))
		{
			return 2;
		}
		else
		{
			ChatMessage cm = new ChatMessage();
			cm.setGame(s);
			cm.setMessage("Waiting for "+ (gameSize.get(s)-hmap.get(s).size()) +" players");
			broadcastHead(cm);
			if(hmap.get(s).size()==1)
			{
				return 3;
			}
			return 0;
		}
	}
	
	// adds a player to a game
	//s is gamename, thread is a player thread.
	public void hashMapAdd(String s, PlayerThread thread)
	{
		if (hmap.containsKey(s))
		{
			 hmap.get(s).add(thread);
		}
		else
		{
			hmap.put(s, new ArrayList<PlayerThread>());
			gameSize.put(s, thread.getGameSize());
			hmap.get(s).add(thread);
		}
	}
	
	//run method inherited from Thread
	@Override
	public void run()
	{
		String deck[] = new String[]{"2","3","4","5","6","7","8","9","10","J","Q","K","A" }; 
		Random rand = new Random();
		try {
			serverSocket = new ServerSocket(6789);

		} catch (IOException e) {
			System.out.println("Invalid Port Number");
		}
		catch(IllegalArgumentException e)
		{
			System.out.println("Invalid Port Number");
		}
		Vector<PlayerThread> threads = new Vector<PlayerThread>();
		while(true)
		{
			try {
				Socket s = null;
				s=serverSocket.accept();
				if(s!=null)
				{
				threads.add(new PlayerThread(s,this));
				if(threads.size()>=2)
				{
					break;
				}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		threads.get(0).broadcast("1");//player1Bet
		String bet;
		while(mess.equals(""))
		{
			System.out.println("wow");
		}
		bet = new String(mess);
		mess="";
		String out = "3"+bet;
		threads.get(1).broadcast(out);//player2Agree
		while(true)
		{
			while(mess.equals(""))
			{
				System.out.println("hii");
			}
		if(mess.equals("No"))
		{
			ChatMessage cm3 = new ChatMessage("2");
			threads.get(0).broadcast("2");//error
			threads.get(1).broadcast("2");//error
			mess="";
			return;
		}
			else if(mess.equals("Yes"))
			{
				mess="";
				break;
			}
		
		}
		while(true)
		{
			int  n = rand.nextInt(13)-1;
			int m = rand.nextInt(13)-1;
			
			String p1 = "4"+deck[n]+deck[m];
			if(n==m)
			{
				p1+="t";
			}
			if(n>m)
			{
				p1+="w";
			}
			else
			{
				p1+="l";
			}
			p1+=bet;
			mess="";
			threads.get(0).broadcast(p1);
			threads.get(1).broadcast(p1);
			if(n!=m)
			{
				threads.get(0).broadcast("2");
				threads.get(1).broadcast("2");
				break;
			}
			while(true)
			{
				if(mess.length()>=2)
				{
					break;
				}
			}
		}
	}
	
	
	//broadcasts a message to all players within a game, specified in the cm.getGame variable
	public void broadcast(ChatMessage cm)
	{
		ArrayList<PlayerThread> threadList = hmap.get(cm.getGame());
		for(int i =0; i<threadList.size();i++)
		{
			threadList.get(i).broadcast(cm.getMessage());
		}
	}
	//broadcasts a message to the first player within a game, specified in the cm.getGame variable
	
	public void broadcastHead(ChatMessage cm)
	{
		ArrayList<PlayerThread> threadList = hmap.get(cm.getGame());

		threadList.get(0).broadcast(cm.getMessage());
	}

}
