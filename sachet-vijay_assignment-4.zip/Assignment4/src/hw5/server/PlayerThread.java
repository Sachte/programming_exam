package hw5.server;
import java.util.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import hw5.Deck;
import hw5.ChatMessage;
public class PlayerThread extends Thread {

	ObjectOutputStream oos;
	ObjectInputStream ois;
	private String userName;
	Socket socket;
	private Server server;
	private boolean bust=false;
	private boolean waiting=false;
	private int chips=500;
	private ArrayList<Integer> cards = new ArrayList<Integer>();
	private int bet=0;
	private int testBet=0;
	private int gameSize=0;
	private int status=0;
	private int status2 =-1;
	private int hitResult=-1;
	public int getGameSize() {return gameSize;}
	
	//constructor, initializes member variables and starts thread
	public PlayerThread(Socket s, Server serv)
	{
		socket=s;
		server=serv;
		this.start();
	}
	
	//name represents gameName, checks if a gamename exists, 
	//by calling respective server method.
	public boolean checkGamename(String name)
	{
		return server.gameExists(name);
	}
	
	//clears the cards member variable
	public void resetCards()
	{
		cards.clear();
	}
	
	//returns the status of the cards by adding up the values, accounts for ace being 1 or 11
	public int status()
	{
		if(status>=status2)
		{
			if(status>21 && status2 > 21)
				return status;
			else if (status>21 && status2<=21 && status2>-1)
			{
				return status2;
			}
			else if(status<=21)
			{
				return status;
			}
			else 
				return status;
		}
		else
		{
			if(status2>21 && status<=21) {
				return status;}
			else if(status2<0) {return status;}
			else {
					return status2;
				}
		}
	}
	
	//Communicates with client to perform the hit operation.
	public void makeHit()
	{
		ChatMessage cm = new ChatMessage();
		cm.setHits(true);
		cm.setChips(chips);
		try {
			oos.writeObject(cm);
			oos.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//adds a card to the cards arraylist
	public void setCard1(int val)
	{
		cards.add(val);
	}
	
	//Communicates with client to perform betting operation
	public void makeBet()
	{
		ChatMessage cm = new ChatMessage();
		cm.setBets(true);
		cm.setChips(chips);
		try {
			oos.writeObject(cm);
			oos.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//getter method
	public String getUserName()
	{
		return userName;
	}
	
	//calculates the status of the deck, status represents when ace is 1, status2 when ace is 11.
	public void getStatus()
	{
		Deck tempDeck = new Deck();
		status=0;
		status2=-1;
		for(int i =0;i<cards.size();i++)
		{
			if(cards.get(i)<4)
			{
				if(status2<0)
				{
					status2=status;
				}
				status += 1;
				status2 += 11;
			}
			else
			{
				status+=tempDeck.getValue(cards.get(i));
				if(status2>=0)
				{
					status2+=tempDeck.getValue(cards.get(i));
				}
			}
		}
	}
	
	//returns a string containining a summary of the player
	public String printSummary()
	{
		Deck tempDeck = new Deck();
		String s="------------------------------------------------\n";
		s+="Player: "+userName+"\n\n";
		getStatus();
		if(status >21)
		{
			if(status2>21 || status2<0)
			{
				s+="Status: "+status+" - bust\n";
			}
			else if(status2 <21)
			{
				s+="Status: "+status2+"\n";
			}
		}
		else if(status==21||status2==21)
		{
			s+="Status: 21 - blackjack\n";
		}
		else if(status2 > 21 && status <21)
		{
			s+="Status: "+status+"\n";
		}
		else if(status2>=0)
		{
			s+="Status: "+status+" or "+status2+"\n";
		}
		else
		{
			s+="Status: "+status+"\n";	
		}
		s+="Cards: | ";
		for(int i =0;i<cards.size();i++)
		{
			s+=" "+tempDeck.getString(cards.get(i))+" |";	
		}
		s+="\n";
		s+="Chip Total: "+chips+" | Bet Amount: "+bet;
		s+="\n------------------------------------------------\n";
		return s;
	}
	//run method inherited.
	@Override
	public void run() {
		try {
			oos = new ObjectOutputStream(socket.getOutputStream());
			oos.flush();
			ois = new ObjectInputStream(socket.getInputStream());
		}catch (IOException ioe) {
				
				System.out.println("ioe in ServerThread.run(): " + ioe.getMessage());
			}

		while(true) {
			try {
				String cm = (String)ois.readObject();

				server.mess+=cm;
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			/*Scanner sc=new Scanner(System.in); 

			while(true) {
				ChatMessage cm = (ChatMessage)ois.readObject();
				if(cm.isCheckGame())
				{
					boolean res=checkGamename(cm.getGame());
					ChatMessage resObj = new ChatMessage();
					resObj.setGameExists(res);
					resObj.setCheckGame(true);
					oos.writeObject(resObj);
					oos.flush();
				}
				else if(cm.getShouldHit()>0)
				{
					hitResult=cm.getShouldHit();
				}
				else if(cm.getBet() >0)
				{
					if(cm.getBet()>getChips())
					{
						broadcast("Please enter bet amount less than chip amount "+getChips());
						makeBet();
					}
					else
					{
					waiting=true;
					bet=cm.getBet();
					setTestBet(bet);
					}
				}
				else
				{
					gameSize=cm.getGameSize();
					userName=cm.getUsername();;
					server.hashMapAdd(cm.getGame(), this);


					String resS = userName+" has joined the game";
					ChatMessage res = new ChatMessage(resS);
					res.setGame(cm.getGame());
					res.setMessage(resS);
					server.broadcastHead(res);
					int resultOfStartGame=server.startGame(cm.getGame());
					if(resultOfStartGame==0) broadcast("Waiting for other players to join...");
					else if(resultOfStartGame==2) broadcast("Attempting to join game that has already started");
				}
			}
		}
		catch (IOException ioe) {
		
			System.out.println("ioe in ServerThread.run(): " + ioe.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		}*/
	}
	
	//s: string to print on client side
	//this method communicates with client side to print to client console.
	public void broadcast(String s)
	{
		ChatMessage msg = new ChatMessage(s);
		try {
			oos.writeObject(msg);
			oos.flush();
		} catch (IOException e) {

			e.printStackTrace();
		}
		
	}
	//getter method
	public int getBet() {
		return bet;
	}
	//setter method
	public void setBet(int bet) {
		this.bet = bet;
	}
	//getter method
	public int getChips() {
		return chips;
	}
	//setter method
	public void setChips(int chips) {
		this.chips = chips;
	}
	//getter method
	public boolean isBust() {
		return bust;
	}
	//setter method
	public void setBust(boolean bust) {
		this.bust = bust;
	}
	//getter method
	public int getHitResult() {
		return hitResult;
	}
	//setter method
	public void setHitResult(int hitResult) {
		this.hitResult = hitResult;
	}
	//getter method
	public int getTestBet() {
		return testBet;
	}
	//setter method
	public void setTestBet(int testBet) {
		this.testBet = testBet;
	}

}