package hw5.server;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import hw5.Deck;
public class Dealer extends Thread{
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	ArrayList<PlayerThread> players;
	private int status=0;
	private int status2 =-1;
	private boolean bust=false;
	private ArrayList<Integer> cards = new ArrayList<Integer>();
	private String userName;
	private Server server;
	private String gameName;
	
	//constructor, initializes member variables
	public Dealer(ArrayList<PlayerThread> list, Server serv, String game)
	{
		players = list;
		server = serv;
		gameName=game;
		this.start();
	}
	//calculates the status of the deck, status represents when ace is 1, status2 when ace is 11.
	
	public void getStatus()
	{
		Deck tempDeck = new Deck();
		status=0;
		status2=-1;
		for(int i =0;i<cards.size();i++)
		{
			if(cards.get(i)<4)
			{
				if(status2<0)
				{
					status2=status;
				}
				status += 1;
				status2 += 11;
			}
			else
			{
				status+=tempDeck.getValue(cards.get(i));
				if(status2>=0)
				{
					status2+=tempDeck.getValue(cards.get(i));
				}
			}
		}
	}
	//returns the status of the cards by adding up the values, accounts for ace being 1 or 11
	
	public int status()
	{
		
		if(status>=status2)
		{
			if(status>21 && status2 > 21)
				return status;
			else if (status>21 && status2<=21 && status2>-1)
			{
				return status2;
			}
			else if(status<=21)
			{
				return status;
			}
			else 
				return status;
		}
		else
		{
			if(status2>21 && status<=21)
				return status;
			else
				return status2;
		}
	}
	//calculates the status of the deck, status represents when ace is 1, status2 when ace is 11.
	
	public void setCard(int val)
	{
		cards.add(val);
	}
	
	//returns a string containining a summary of the player, intended for after betting
	
	public String printSummary()
	{
		Deck tempDeck = new Deck();
		String s="------------------------------------------------\n";
		s+="DEALER\n\n";

		
		s+="Cards: | ? |";
		for(int i =1;i<cards.size();i++)
		{
			s+=" "+tempDeck.getString(cards.get(i))+" |";	
		}

		s+="\n------------------------------------------------\n";
		return s;
	}
	//returns a string containining a summary of the player, intended for after round
	public String printSummary2()
	{
		Deck tempDeck = new Deck();
		String s="------------------------------------------------\n";
		s+="DEALER\n\n";
		getStatus();
		if(status >21)
		{
			if(status2>21 || status2<0)
			{
				s+="Status: "+status+" - bust\n";
			}
			else if(status2 <21)
			{
				s+="Status: "+status2+"\n";
			}
		}
		else if(status==21||status2==21)
		{
			s+="Status: 21 - blackjack\n";
		}
		else if(status2 > 21 && status <21)
		{
			s+="Status: "+status+"\n";
		}
		else if(status2>=0)
		{
			s+="Status: "+status+" or "+status2+"\n";
		}
		else
		{
			s+="Status: "+status+"\n";	
		}
		
		s+="Cards: |";
		for(int i =0;i<cards.size();i++)
		{
			s+=" "+tempDeck.getString(cards.get(i))+" |";	
		}

		s+="\n------------------------------------------------\n";
		return s;
	}
	
	//runs the thread
	@Override
	public void run()
	{
		Deck deck = new Deck();
		int majorCounter=0;
		while(true)
		{
			//start of new round
			majorCounter++;
			deck.flush();
			for(int i=0;i<players.size();i++)
			{
				players.get(i).resetCards();
				cards.clear();
				players.get(i).broadcast("ROUND " +majorCounter+"\nDealer is shuffling his cards");

			}
			//making bets
			for(int i=0;i<players.size();i++)
			{
				PlayerThread player = players.get(i);
				if(player.getChips()<=0)
				{
					continue;
				}
				for(int j=0;j<players.size();j++)
				{
					if(j==i)
					{
						player.makeBet();

					}
					else
					{
						players.get(j).broadcast("It is "+player.getUserName()+"'s turn to make a bet");

					}
				}
				while(player.getTestBet()==0)
				{
					System.err.print("");
				}
				
				for(int j=0;j<players.size();j++)
				{
					if(j!=i)
					{

						players.get(j).broadcast(player.getUserName()+" bet "+player.getBet()+" chips");

					}
				}
				player.setTestBet(0);
			}
			//finished making bets, printing summary
			String summary="";
			setCard(deck.random());
			setCard(deck.random());
			
			summary+=printSummary();
			for(int j=0;j<players.size();j++)
			{
				
				players.get(j).setCard1(deck.random());
				players.get(j).setCard1(deck.random());
				
				summary+=players.get(j).printSummary();

			}
			for(int i=0;i<players.size();i++)
			{
				players.get(i).broadcast(summary);

			}
			
			//After betting, adding cards to hands
			for(int i=0;i<players.size();i++)
			{
				PlayerThread player = players.get(i);
				if(player.getChips()<=0)
				{
					continue;
				}
				for(int j=0;j<players.size();j++)
				{
					if(j==i)
					{
						if(player.getChips()<=0)
						{
							continue;
						}
						player.broadcast("It is your turn to add cards to your hand");
					}
					else
					{
						players.get(j).broadcast("It is "+player.getUserName()+"'s turn to add cards to their hand");

					}
				}
						while(true)
						{
							player.makeHit();
							while(player.getHitResult()==-1)
							{
								System.err.print("");
							}
							int result=player.getHitResult();
							player.setHitResult(-1);
							if(result!=2)
							{
								//check if bust if so
								if(result==0)
								{
									player.setBust(true);
								}
								for(int j=0;j<players.size();j++)
								{
									if(j==i)
									{
										player.broadcast("You Stayed.");
									}
									else
									{
										System.err.println("wowo: "+j);
										players.get(j).broadcast(player.getUserName()+" stayed.");
									}
									
										players.get(j).broadcast(player.printSummary());
									
								}
								break;
							}
							else
							{
								int card = deck.random();
								player.setCard1(card);
								player.getStatus();
								if(player.status()>21)
								{
									player.setBust(true);
									for(int j=0;j<players.size();j++)
									{
										if(j==i)
										{
											player.broadcast("You Bust.");
										}
										else
										{
											players.get(j).broadcast(player.getUserName()+" bust.");
										}
										players.get(j).broadcast(player.printSummary());
										
									}
									break;
								}
								for(int j=0;j<players.size();j++)
								{
									System.err.println("j: "+j);
									if(j==i)
									{
										player.broadcast("You hit. You were dealt the "+deck.getString(card));
									}
									else
									{
										System.err.println("wowo: "+j);
										players.get(j).broadcast(player.getUserName()+" hit. They were dealt the "+deck.getString(card));
									}
								}
								
							}
							
						}
			}
			
			//dealer's turn to add cards
			for(int k=0;k<players.size();k++)
			{
				players.get(k).broadcast("It is now time for the dealer to play");
			}
				int j=1;
				getStatus();
				int statusVal = status();
				if(statusVal>=17 )
				{
					for(int k=0;k<players.size();k++)
					{
						if(statusVal<21)
						{
						players.get(k).broadcast("Dealer Stayed.");
						}
						players.get(k).broadcast(printSummary2());
					}
				}
				else
				{
				while(true)
				{
					int card = deck.random();
					setCard(card);
					getStatus();
					int statusValue = status();

					int count=1;
					if(statusValue>=17 )
					{
						for(int k=0;k<players.size();k++)
						{
							players.get(k).broadcast("Dealer hit "+count+" times, they were dealt the "+deck.getString(card));
							players.get(k).broadcast(printSummary2());
						}
						break;
					}
					else
					{			
						for(int k=0;k<players.size();k++)
						{
							players.get(k).broadcast("Dealer hit "+count+" times");
						}		
					}
					count++;
				}
				}
				getStatus();
				boolean isZeroChips=false;
				for(int i=0;i<players.size();i++)
				{
					PlayerThread player = players.get(i);
					player.getStatus();
					for(int a=0;a<players.size();a++)
					{
						if(a==i)
						{

							if(player.status()>21)
							{

									player.broadcast("you busted. " + player.getBet() +" chips were deducted from your total");
									player.setChips(player.getChips()-player.getBet());
								
							}
							else if(player.status()==21)
							{
								if(status()==21)	
								{
									player.broadcast("you had blackjack, and so did the dealer " + player.getBet() +" chips were added to your total");
									player.setChips(player.getChips()+player.getBet());
								}
								else 
								{
									player.broadcast("you had blackjack. " + 2*player.getBet() +" chips were added to your total");
									player.setChips(player.getChips()+2*player.getBet());
								}
								
							}
							else if(player.status()==status() && status()<=21)
							{
								player.broadcast("you had same total as dealer. " + 0 +" chips were added to your total");
							}
							else if(player.status()<status()&& status()<=21)
							{
								player.broadcast("you had lower total than dealer. " + player.getBet() +" chips were deducted from your total");
								player.setChips(player.getChips()-player.getBet());
							}
							else
							{
								player.broadcast("you had higher total than your dealer. " + player.getBet() +" chips were added to your total");	
								player.setChips(player.getChips()+player.getBet());
							}
							
						}
						else
						{
							PlayerThread playera = players.get(a);
							if(player.status()>21 || player.isBust())
							{

									playera.broadcast(player.getUserName()+" busted. " + player.getBet() +" chips were added to "+player.getUserName()+"'s total");
							}
							else if(player.status()==21)
							{
								if(status()==21)	
								{
									playera.broadcast(player.getUserName()+" had blackjack, and so did the dealer " + player.getBet() +" chips were added to "+player.getUserName()+"'s total");
								}
								else 
								{
									playera.broadcast(player.getUserName()+" had blackjack. " + 2*player.getBet() +" chips were added to "+player.getUserName()+"'s total");
								}
								
							}
							else if(player.status()==status()&& status()<=21)
							{
								playera.broadcast(player.getUserName()+" had same total as dealer. " + 0 +" chips were added to "+player.getUserName()+"'s total");
							}
							else if(player.status()<status()&& status()<=21)
							{
								playera.broadcast(player.getUserName()+" had lower total than dealer. " + player.getBet() +" chips were deducted from "+player.getUserName()+"'s total");
							}
							else
							{
								playera.broadcast(player.getUserName()+" had higher total than dealer. " + player.getBet() +" chips were added to "+player.getUserName()+"'s total");	
							}
							
						}
						
					}
					if(player.getChips()==0) isZeroChips=true;
				}
				
				summary="";
				summary+=printSummary2();
				for(int t=0;t<players.size();t++)
				{
					summary+=players.get(t).printSummary();
				}
				for(int i=0;i<players.size();i++)
				{
					players.get(i).broadcast(summary);
				}
				
				if(isZeroChips)break;
		}
		int maxInd=0;
		int maxChips=0;
		int minInd=0;
		for(int i=0;i<players.size();i++)
		{
			if(players.get(i).getChips()>maxChips)
			{
				maxChips=players.get(i).getChips();
				maxInd=i;
			}
			if(players.get(i).getChips()<=0)
			{
				minInd=i;
			}
		}
		//determination of winner
		for(int i=0;i<players.size();i++)
		{
			if(maxChips==0)
			{
				players.get(i).broadcast("Everyone has 0 Chips, so the dealer is the WINNER!");
			}
			else
			{
				players.get(i).broadcast(players.get(maxInd).getUserName()+" is the WINNER!\n"+players.get(minInd).getUserName()+" is the LOSER!");
		
			}
		}
		server.removeGame(gameName);
	}
}
